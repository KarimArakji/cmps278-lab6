function getSize() {
    slider = document.getElementById("slider");
    return slider.value;
}

function getMeat() {
    var arrayy = []
    if (document.getElementById("Pepperoni").checked) {
        arrayy.push(document.getElementById("Pepperoni").id)
    }
    if (document.getElementById("Sausage").checked) {
        arrayy.push(document.getElementById("Sausage").id)
    }
    if (document.getElementById("GroundBeef").checked) {
        arrayy.push(document.getElementById("GroundBeef").id)
    }
    if (document.getElementById("Anchovy").checked) {
        arrayy.push(document.getElementById("Anchovy").id)
    }
    if (document.getElementById("Chicken").checked) {
        arrayy.push(document.getElementById("Chicken").id)
    }

    return arrayy;
}


function getVeg() {
    var arrayy = []
    if (document.getElementById("Tomatoes").checked) {
        arrayy.push(document.getElementById("Tomatoes").id)
    }
    if (document.getElementById("Onions").checked) {
        arrayy.push(document.getElementById("Onions").id)
    }
    if (document.getElementById("Olives").checked) {
        arrayy.push(document.getElementById("Olives").id)
    }
    if (document.getElementById("Mushrooms").checked) {
        arrayy.push(document.getElementById("Mushrooms").id)
    }
    if (document.getElementById("Pineapple").checked) {
        arrayy.push(document.getElementById("Pineapple").id)
    }
    if (document.getElementById("Spinach").checked) {
        arrayy.push(document.getElementById("Spinach").id)
    }
    if (document.getElementById("Jalapeno").checked) {
        arrayy.push(document.getElementById("Jalapeno").id)
    }

    return arrayy;
}

function getCheese() {
    if (document.getElementById("RegularCheese").checked) {
        return 1;
    } else if (document.getElementById("NoCheese").checked) {
        return 2;
    } else if (document.getElementById("ExtraCheese").checked) {
        return 3;
    }
}

function ChangePizzaSize() {

    var cost = 0;

    if (document.getElementById("slider").value == "1") {
        document.getElementById("pizzaImage").style.width = "100px";
        document.getElementById("Cost").innerHTML = "Small $6";
        cost += 6;
    } else if (document.getElementById("slider").value == "2") {
        document.getElementById("pizzaImage").style.width = "150px";
        document.getElementById("Cost").innerHTML = "Medium $10";
        cost += 10;
    } else if (document.getElementById("slider").value == "3") {
        document.getElementById("pizzaImage").style.width = "200px";
        document.getElementById("Cost").innerHTML = "Large $14";
        cost += 14;
    } else if (document.getElementById("slider").value == "4") {
        document.getElementById("pizzaImage").style.width = "250px";
        document.getElementById("Cost").innerHTML = "X-Large $16";
        cost += 16;
    }

    return cost;
}

function calculateTotal() {

    var Total = 0;
    Total += ChangePizzaSize();
    Total += getMeat().length * 2;
    Total += getVeg().length;
    if (getCheese() == 3) {
        Total += 3;
    }
    return Total

}

function fillSummary() {



    var total_ = calculateTotal();
    var cheese = getCheese();
    var veg = getVeg();
    var meat = getMeat();
    var size_ = getSize();
    var firstname = document.getElementById("FirstName").value;
    var lastname = document.getElementById("LastName").value;
    var email = document.getElementById("Email").value;
    var address = document.getElementById("Address1").value;
    var city = document.getElementById("CityName").value;
    var phone = document.getElementById("Phone").value;

    document.getElementById("dlvrTo").innerHTML =
        firstname +
        " , " +
        lastname +
        " , " +
        email +
        " , " +
        phone +
        " , " +
        city +
        " - " +
        address;

    document.getElementById("total").innerHTML = "Total: " + total_ + " $";

    if (size_ == "1") {
        document.getElementById("orderList").innerHTML += ('<li>' + "-Small size" + '</li>');
    } else if (size_ == "2") {
        document.getElementById("orderList").innerHTML += ('<li>' + "-Medium size" + '</li>');
    } else if (size_ == "3") {
        document.getElementById("orderList").innerHTML += ('<li>' + "-Large Size" + '</li>');
    } else if (size_ == "4") {
        document.getElementById("orderList").innerHTML += ('<li>' + "-X-Large Size" + '</li>');
    }

    if (cheese == "1") {
        document.getElementById("orderList").innerHTML += ('<li>' + "Regular Cheese" + '</li>');
    } else if (cheese == "2") {
        document.getElementById("orderList").innerHTML += ('<li>' + "No Cheese" + '</li>');
    } else if (cheese == "3") {
        document.getElementById("orderList").innerHTML += ('<li>' + "Extra Cheese" + '</li>');
    }

    for (var i = 0; i < veg.length; i++) {

        document.getElementById("orderList").innerHTML += ('<li>' + veg[i] + '</li>');

    }

    for (var i = 0; i < meat.length; i++) {

        document.getElementById("orderList").innerHTML += ('<li>' + meat[i] + '</li>');
    }

}

function goToPage(a) {
    if (a == 1) {
        document.getElementById("form1").style.display = "block";
        document.getElementById("form2").style.display = "none";
        document.body.style.background = "#01dddd";
        document.getElementById("OrderSummary").style.display = "none";
    } else if (a == 2) {
        document.getElementById("form1").style.display = "none";
        document.getElementById("form2").style.display = "block";
        document.getElementById("OrderSummary").style.display = "none";
        document.body.style.background = "#e93a57";
    } else if (a == 3) {
        document.getElementById("form1").style.display = "none";
        document.getElementById("form2").style.display = "none";
        document.getElementById("OrderSummary").style.display = "block";
        document.body.style.background = "#3fc38e";
    }

}

function checkInfo() {
    form2 = document.getElementById("form2");
    var city_ = document.getElementById("CityName").value;
    var firstname = document.getElementById("FirstName").value;
    var lastname = document.getElementById("LastName").value;
    var email = document.getElementById("Email").value;
    var address = document.getElementById("Address1").value;
    var phone = document.getElementById("Phone").value;
    if (
        firstname == "" ||
        lastname == "" ||
        email == "" ||
        address == "" ||
        city_ == "--Please choose an option--" ||
        phone == ""
    ) {

        alert("All fields are required!");
        form2.name.focus;
        return false;
    }

    return true;
}

function buttoncheck() {
    if (checkInfo() == true) {
        goToPage(3);
    } else {
        return;
    }
}